# Codveda Web Development Internship: Level 3 (Advanced)

| Task | Folder |
|------|--------|
| 1. Full-stack CRUD application | task1-fullstack-crud |
| 2. User authentication system | task2-authentication |

Both need Node.js 18+ and MongoDB. See the README in each folder.
