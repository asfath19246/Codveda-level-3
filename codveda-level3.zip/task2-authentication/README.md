# Task 2: User authentication system

Stack: Node.js, Express, MongoDB (Mongoose), JWT, bcrypt.

## Run
    cp .env.example .env     # then set JWT_SECRET to a long random value
    npm install
    npm run dev              # open http://localhost:4000

## Endpoints
| Method | Path | Access | Purpose |
|--------|------|--------|---------|
| POST | /api/auth/register | public | Create account, sets login cookie |
| POST | /api/auth/login | public | Log in, sets login cookie |
| POST | /api/auth/logout | public | Clears the cookie |
| GET | /api/auth/me | protected | Current user |
| GET | /api/secret | protected | Example protected data |

## Security features
- Passwords hashed with bcrypt (12 rounds); hash never returned by the API
- JWT (7 day expiry) stored in an httpOnly, SameSite=Strict cookie (Secure in production)
- Protected routes use the requireAuth middleware
- Input type checks (stops NoSQL injection), length limits, generic login error message
- Rate limit on login and register; helmet security headers

## Test with curl
    curl -i -c jar.txt -X POST localhost:4000/api/auth/register -H "Content-Type: application/json" -d '{"name":"Test User","email":"test@example.com","password":"password123"}'
    curl -b jar.txt localhost:4000/api/auth/me      # 200 with user
    curl localhost:4000/api/auth/me                  # 401 without cookie

## Notes
- Registration tells people when an email is already taken. That is common, but it does reveal which emails have accounts.
- Serve the app over HTTPS in production and set NODE_ENV=production.
