const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Protects a route: requires a valid JWT (cookie, or "Authorization: Bearer <token>").
module.exports = async function requireAuth(req, res, next) {
  try {
    let token = req.cookies && req.cookies.token;
    const header = req.headers.authorization;
    if (!token && header && header.startsWith('Bearer ')) token = header.slice(7);
    if (!token) return res.status(401).json({ error: 'Please log in' });

    const payload = jwt.verify(token, process.env.JWT_SECRET); // throws if invalid or expired
    const user = await User.findById(payload.sub);
    if (!user) return res.status(401).json({ error: 'Please log in' });

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Session expired. Please log in again' });
  }
};
