const $ = (id) => document.getElementById(id);
const page = document.body.dataset.page;

async function api(path, options = {}) {
  const res = await fetch('/api' + path, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    ...options
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, data };
}

if (page === 'auth') {
  const msg = $('msg');
  const show = (text) => { msg.textContent = text; };

  function switchTab(toRegister) {
    $('loginForm').hidden = toRegister;
    $('registerForm').hidden = !toRegister;
    $('tabLogin').classList.toggle('active', !toRegister);
    $('tabRegister').classList.toggle('active', toRegister);
    $('tabLogin').setAttribute('aria-selected', String(!toRegister));
    $('tabRegister').setAttribute('aria-selected', String(toRegister));
    show('');
  }
  $('tabLogin').addEventListener('click', () => switchTab(false));
  $('tabRegister').addEventListener('click', () => switchTab(true));

  // Already logged in? Go straight to the dashboard.
  api('/auth/me').then((r) => { if (r.ok) location.replace('/dashboard.html'); });

  async function submit(path, body) {
    show('');
    const r = await api(path, { method: 'POST', body: JSON.stringify(body) });
    if (r.ok) location.href = '/dashboard.html';
    else show(r.data.error || 'Something went wrong');
  }

  $('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    submit('/auth/login', { email: $('lEmail').value, password: $('lPass').value });
  });
  $('registerForm').addEventListener('submit', (e) => {
    e.preventDefault();
    submit('/auth/register', { name: $('rName').value, email: $('rEmail').value, password: $('rPass').value });
  });
}

if (page === 'dashboard') {
  (async () => {
    const me = await api('/auth/me');
    if (!me.ok) { location.replace('/'); return; }          // not logged in
    $('hello').textContent = 'Hello, ' + me.data.user.name;
    $('email').textContent = 'Signed in as ' + me.data.user.email;
    const secret = await api('/secret');
    $('secret').textContent = secret.ok ? secret.data.message : '';
  })();

  $('logout').addEventListener('click', async () => {
    await api('/auth/logout', { method: 'POST' });
    location.replace('/');
  });
}
