const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const requireAuth = require('../middleware/auth');

const router = express.Router();
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const SALT_ROUNDS = 12;
// Used so a login for an unknown email takes about as long as a real one.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', SALT_ROUNDS);

const cookieOptions = {
  httpOnly: true,                                   // JavaScript cannot read the cookie
  sameSite: 'strict',                               // blocks cross-site requests (CSRF)
  secure: process.env.NODE_ENV === 'production',    // HTTPS only in production
  maxAge: 7 * 24 * 60 * 60 * 1000
};

const signToken = (userId) =>
  jwt.sign({ sub: userId }, process.env.JWT_SECRET, { expiresIn: '7d' });

const publicUser = (u) => ({ id: u._id, name: u.name, email: u.email, createdAt: u.createdAt });
const isString = (v) => typeof v === 'string';
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// POST /api/auth/register
router.post('/register', wrap(async (req, res) => {
  const { name, email, password } = req.body || {};

  if (!isString(name) || name.trim().length < 2 || name.trim().length > 60)
    return res.status(400).json({ error: 'Name must be 2 to 60 characters' });
  if (!isString(email) || !EMAIL_RE.test(email.trim()))
    return res.status(400).json({ error: 'Enter a valid email address' });
  // bcrypt only uses the first 72 bytes, so cap the length
  if (!isString(password) || password.length < 8 || Buffer.byteLength(password) > 72)
    return res.status(400).json({ error: 'Password must be 8 to 72 characters' });

  const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
  try {
    const user = await User.create({ name, email, passwordHash });
    res.cookie('token', signToken(user._id), cookieOptions);
    res.status(201).json({ user: publicUser(user) });
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ error: 'That email is already registered' });
    throw err;
  }
}));

// POST /api/auth/login
router.post('/login', wrap(async (req, res) => {
  const { email, password } = req.body || {};
  // Type checks stop NoSQL injection such as {"email": {"$gt": ""}}
  if (!isString(email) || !isString(password))
    return res.status(400).json({ error: 'Enter your email and password' });

  const user = await User.findOne({ email: email.trim().toLowerCase() }).select('+passwordHash');
  const ok = await bcrypt.compare(password, user ? user.passwordHash : DUMMY_HASH);
  if (!user || !ok) return res.status(401).json({ error: 'Invalid email or password' });

  res.cookie('token', signToken(user._id), cookieOptions);
  res.json({ user: publicUser(user) });
}));

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  res.clearCookie('token', { ...cookieOptions, maxAge: undefined });
  res.json({ ok: true });
});

// GET /api/auth/me  (protected)
router.get('/me', requireAuth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

module.exports = router;
