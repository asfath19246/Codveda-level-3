const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, minlength: 2, maxlength: 60 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    // select:false keeps the hash out of queries unless explicitly requested
    passwordHash: { type: String, required: true, select: false }
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);
