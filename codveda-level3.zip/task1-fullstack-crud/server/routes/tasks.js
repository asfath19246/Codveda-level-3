const express = require('express');
const mongoose = require('mongoose');
const Task = require('../models/Task');

const router = express.Router();

// Express 4 does not catch errors from async handlers, so wrap them.
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

// Allow only these fields from the request body (prevents mass assignment).
const ALLOWED = ['title', 'description', 'status'];
const pick = (body = {}) => {
  const out = {};
  for (const key of ALLOWED) if (body[key] !== undefined) out[key] = body[key];
  return out;
};

// Reject malformed ids before they reach the database.
router.param('id', (req, res, next, id) => {
  if (!mongoose.isValidObjectId(id)) return res.status(400).json({ error: 'Invalid task id' });
  next();
});

// CREATE
router.post('/', wrap(async (req, res) => {
  const task = await Task.create(pick(req.body));
  res.status(201).json(task);
}));

// READ (all, optional ?status=todo)
router.get('/', wrap(async (req, res) => {
  const filter = {};
  if (typeof req.query.status === 'string') filter.status = req.query.status;
  const tasks = await Task.find(filter).sort({ createdAt: -1 });
  res.json(tasks);
}));

// READ (one)
router.get('/:id', wrap(async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  res.json(task);
}));

// UPDATE
router.put('/:id', wrap(async (req, res) => {
  const task = await Task.findByIdAndUpdate(req.params.id, pick(req.body), {
    new: true,
    runValidators: true
  });
  if (!task) return res.status(404).json({ error: 'Task not found' });
  res.json(task);
}));

// DELETE
router.delete('/:id', wrap(async (req, res) => {
  const task = await Task.findByIdAndDelete(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  res.status(204).end();
}));

module.exports = router;
