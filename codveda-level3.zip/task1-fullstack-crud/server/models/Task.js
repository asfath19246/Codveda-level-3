const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema(
  {
    title: { type: String, required: [true, 'Title is required'], trim: true, minlength: 1, maxlength: 120 },
    description: { type: String, trim: true, maxlength: 500, default: '' },
    status: { type: String, enum: ['todo', 'in-progress', 'done'], default: 'todo' }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Task', taskSchema);
