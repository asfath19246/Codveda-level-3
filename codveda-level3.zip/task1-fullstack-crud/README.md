# Task 1: Full-stack CRUD application (Task manager)

Stack: Node.js, Express, MongoDB (Mongoose), React (Vite).

## Requirements
Node.js 18+ and MongoDB running locally (or a free MongoDB Atlas connection string).

## Run
Terminal 1 (API):
    cd server
    cp .env.example .env      # edit MONGODB_URI if needed
    npm install
    npm run dev

Terminal 2 (front end):
    cd client
    npm install
    npm run dev               # open http://localhost:5173

## REST API
| Method | Path | Purpose |
|--------|------|---------|
| POST | /api/tasks | Create a task |
| GET | /api/tasks | List tasks (optional ?status=todo) |
| GET | /api/tasks/:id | Get one task |
| PUT | /api/tasks/:id | Update title, description or status |
| DELETE | /api/tasks/:id | Delete a task |

Quick test:
    curl -X POST http://localhost:5000/api/tasks -H "Content-Type: application/json" -d '{"title":"Test"}'
