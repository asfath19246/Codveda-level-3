import { useEffect, useState } from 'react';
import { api } from './api.js';
import TaskForm from './components/TaskForm.jsx';
import TaskItem from './components/TaskItem.jsx';

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // READ
  useEffect(() => {
    api.list().then(setTasks).catch((e) => setError(e.message)).finally(() => setLoading(false));
  }, []);

  // CREATE
  async function addTask(task) {
    setError('');
    try {
      const created = await api.create(task);
      setTasks((prev) => [created, ...prev]);
      return true;
    } catch (e) {
      setError(e.message);
      return false;
    }
  }

  // UPDATE
  async function updateTask(id, changes) {
    setError('');
    try {
      const updated = await api.update(id, changes);
      setTasks((prev) => prev.map((t) => (t._id === id ? updated : t)));
      return true;
    } catch (e) {
      setError(e.message);
      return false;
    }
  }

  // DELETE
  async function deleteTask(id) {
    setError('');
    try {
      await api.remove(id);
      setTasks((prev) => prev.filter((t) => t._id !== id));
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <main className="app">
      <h1>Task manager</h1>
      <TaskForm onAdd={addTask} />
      {error && <p className="error" role="alert">{error}</p>}
      {loading ? (
        <p className="muted">Loading tasks...</p>
      ) : tasks.length === 0 ? (
        <p className="muted">No tasks yet. Add your first one above.</p>
      ) : (
        <ul className="list">
          {tasks.map((t) => (
            <TaskItem key={t._id} task={t} onUpdate={updateTask} onDelete={deleteTask} />
          ))}
        </ul>
      )}
    </main>
  );
}
