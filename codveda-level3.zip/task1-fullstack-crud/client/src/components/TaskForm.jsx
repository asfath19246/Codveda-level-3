import { useState } from 'react';

export default function TaskForm({ onAdd }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    if (!title.trim()) return;
    const ok = await onAdd({ title, description });
    if (ok) { setTitle(''); setDescription(''); }
  }

  return (
    <form className="form" onSubmit={handleSubmit}>
      <label htmlFor="title" className="sr">Title</label>
      <input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Task title" maxLength={120} />
      <label htmlFor="desc" className="sr">Description</label>
      <input id="desc" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description (optional)" maxLength={500} />
      <button className="primary" type="submit">Add task</button>
    </form>
  );
}
