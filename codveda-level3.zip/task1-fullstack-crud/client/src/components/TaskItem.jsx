import { useState } from 'react';

const STATUSES = [
  { value: 'todo', label: 'To do' },
  { value: 'in-progress', label: 'In progress' },
  { value: 'done', label: 'Done' }
];

export default function TaskItem({ task, onUpdate, onDelete }) {
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description || '');

  async function save() {
    if (!title.trim()) return;
    const ok = await onUpdate(task._id, { title, description });
    if (ok) setEditing(false);
  }

  function cancel() {
    setTitle(task.title);
    setDescription(task.description || '');
    setEditing(false);
  }

  return (
    <li className={'item ' + task.status}>
      {editing ? (
        <div className="edit">
          <input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} aria-label="Title" />
          <input value={description} onChange={(e) => setDescription(e.target.value)} maxLength={500} aria-label="Description" />
          <div className="actions">
            <button className="primary" onClick={save}>Save</button>
            <button onClick={cancel}>Cancel</button>
          </div>
        </div>
      ) : (
        <>
          <div className="info">
            <strong>{task.title}</strong>
            {task.description && <p>{task.description}</p>}
          </div>
          <div className="actions">
            <select
              value={task.status}
              onChange={(e) => onUpdate(task._id, { status: e.target.value })}
              aria-label={'Status for ' + task.title}
            >
              {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
            <button onClick={() => setEditing(true)}>Edit</button>
            <button className="danger" onClick={() => onDelete(task._id)}>Delete</button>
          </div>
        </>
      )}
    </li>
  );
}
